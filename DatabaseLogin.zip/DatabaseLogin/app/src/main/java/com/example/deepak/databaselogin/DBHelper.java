package com.example.deepak.databaselogin;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by DEEPAK on 15-08-2016.
 */
public class DBHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME="Database";
    public static final int DATABASE_VERSION=1;
    public static final String CREATE_QUERY=
            "CREATE TABLE USER_INFO ( NAME text ,EMAIL text,PHONE text,PASSWORD text);";
    SQLiteDatabase db;


    public DBHelper(Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);

    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_QUERY);
        Log.e("Database Operation","Database Created");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void addInformation(String name,String email,String password,String phone,SQLiteDatabase db){
        ContentValues contentValues=new ContentValues();
        contentValues.put("NAME",name);
        contentValues.put("EMAIL",email);
        contentValues.put("PASSWORD",password);
        contentValues.put("PHONE",phone);

        db.insert("USER_INFO",null,contentValues);
        Log.e("Database Operation","1 row of data inserted");
    }

    public Cursor getInformation(String name,SQLiteDatabase db){
        String[] args={name};
        Cursor cursor=db.query("USER_INFO",new String[] {"PASSWORD","EMAIL","PHONE"},"NAME = ?",args,null,null,null);
        return  cursor;

    }
    public void deleteInformation(String name,SQLiteDatabase db){
        String[] args={name};
        db.delete("USER_INFO","NAME = ?",args);
        db.close();

    }
}
