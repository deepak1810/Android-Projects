package com.example.deepak.databaselogin;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class SearchContact extends AppCompatActivity {

    EditText username;
    TextView userPhone,userEmail,userPassword;
    DBHelper dbHelper;
    SQLiteDatabase db;
    String phone,email,password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_contact);

        username= (EditText) findViewById(R.id.et_searchname);
        userEmail= (TextView) findViewById(R.id.tv_searchEmailResult);
        userPassword= (TextView) findViewById(R.id.tv_searchPasswordResult);
        userPhone= (TextView) findViewById(R.id.tv_searchPhoneResult);

    }

    public void onSearchResult(View view){
        String name;
        name=username.getText().toString();
        dbHelper=new DBHelper(getApplicationContext());
        db=dbHelper.getReadableDatabase();
        Cursor cursor=dbHelper.getInformation(name,db);

        if(cursor.moveToFirst()){
            password=cursor.getString(0);
            email=cursor.getString(1);
            phone=cursor.getString(2);

            userEmail.setText(email);
            userPassword.setText(password);
            userPhone.setText(phone);
            db.close();
        }
        else{
                Toast.makeText(this,"UserName does not exist",Toast.LENGTH_LONG).show();
            db.close();
        }

    }
}
