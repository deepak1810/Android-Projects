package com.example.deepak.databaselogin;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class SignUp extends AppCompatActivity {

    EditText username,userpassword,useremail,userphone;
    DBHelper dbHelper;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        username= (EditText) findViewById(R.id.et_newUsername);
        useremail= (EditText) findViewById(R.id.et_newEmail);
        userpassword= (EditText) findViewById(R.id.et_newPassword);
        userphone= (EditText) findViewById(R.id.et_newPhone);
    }

    public void onAgree(View view){
        String name,email,password,phone;
        name=username.getText().toString();
        email=useremail.getText().toString();
        password=userpassword.getText().toString();
        phone=userphone.getText().toString();

        if(name.equals("")||phone.equals("")||email.equals("")||password.equals("")){
            Toast.makeText(getApplicationContext(),"Field cannot be left Empty",Toast.LENGTH_LONG).show();
        }
        else{
            dbHelper=new DBHelper(getApplicationContext());
            db=dbHelper.getWritableDatabase();
            dbHelper.addInformation(name,email,password,phone,db);
            db.close();

            Intent intent=new Intent(this,Garbage.class);
            startActivity(intent);
        }



    }
}
