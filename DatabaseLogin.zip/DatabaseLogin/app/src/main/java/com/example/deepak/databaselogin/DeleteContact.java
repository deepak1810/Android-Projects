package com.example.deepak.databaselogin;

import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class DeleteContact extends AppCompatActivity {
    EditText username;
    SQLiteDatabase db;
    DBHelper dbHelper;
    String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_contact);

        username= (EditText) findViewById(R.id.et_deletename);

    }
    public void onDelete(View view){
        name=username.getText().toString();
        dbHelper=new DBHelper(getApplicationContext());
        db=dbHelper.getReadableDatabase();
        dbHelper.deleteInformation(name,db);
        Toast.makeText(this,"Contact successfully deleted!!!",Toast.LENGTH_LONG).show();
        db.close();
    }
}
