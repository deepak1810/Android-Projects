package com.example.deepak.databaselogin;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class UserLogin extends AppCompatActivity {

    EditText username,userpassword;
    SQLiteDatabase db;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);

        username= (EditText) findViewById(R.id.et_username);
        userpassword= (EditText) findViewById(R.id.et_password);
    }

    public void onSubmit(View view){
        String name,password;
        name=username.getText().toString();
        password=userpassword.getText().toString();

        if(name.equals("")||password.equals("")){
            Toast.makeText(getApplicationContext(),"Username or Password field is empty!",Toast.LENGTH_LONG).show();

        }

        dbHelper=new DBHelper(getApplicationContext());
        db=dbHelper.getReadableDatabase();
        Cursor cursor=dbHelper.getInformation(name,db);

        if(cursor.moveToFirst()){
            String password_saved=cursor.getString(0);
            if(password.equals(password_saved)){
                Intent intent=new Intent(this,Garbage.class);
                startActivity(intent);
            }
            else{
                Toast.makeText(getApplicationContext(),"Username or Password did not match!",Toast.LENGTH_LONG).show();
            }
        }
    }

    public void onCreateNewAcc(View view){
        Intent intent=new Intent(this,SignUp.class);
        startActivity(intent);
    }
}
