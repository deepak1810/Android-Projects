package com.example.deepak.databaselogin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onAdmin(View view){
        Intent intent=new Intent(getApplicationContext(),AdminLogin.class);
        startActivity(intent);
    }
    public void onUserLogin(View view){
        Intent intent=new Intent(getApplicationContext(),UserLogin.class);
        startActivity(intent);
    }
}
