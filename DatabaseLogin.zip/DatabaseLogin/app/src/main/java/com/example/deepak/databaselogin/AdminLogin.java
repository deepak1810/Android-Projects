package com.example.deepak.databaselogin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class AdminLogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);



    }

    public void onViewContact(View view){
        Intent intent=new Intent(this,ViewContactList.class);
        startActivity(intent);
    }
    public void onSearchContact(View view){
        Intent intent=new Intent(this,SearchContact.class);
        startActivity(intent);
    }
    public void onDeleteContact(View view){
        Intent intent=new Intent(this,DeleteContact.class);
        startActivity(intent);
    }
}
